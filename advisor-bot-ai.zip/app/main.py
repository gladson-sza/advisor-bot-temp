from fastapi import FastAPI, Body
from starlette import status

import logging

import os
from openai import OpenAI

api_key = os.getenv("API_KEY")
client = OpenAI(api_key=api_key) 

app = FastAPI()

@app.get("/")
async def home():
    return "Welcome to the API for an Advisor Bot"


@app.get("/chat", status_code=status.HTTP_200_OK)
async def chat(prompt=Body()):
    logging.log(logging.INFO, f'User Query: {prompt}')
  
    response = client.chat.completions.create(
          model="o1-preview",
          messages=[
            {"role": "assistant", "content": "You are a assistant, that gives user's advice. You will receive a question and need to answer the user question about the topic it asks. Be polite."},
            {"role": "user", "content": prompt}
          ],
    )
    
    logging.log(logging.INFO, f'Response: {response.choices[0].message.content}')
    
    return response.choices[0].message.content
    
