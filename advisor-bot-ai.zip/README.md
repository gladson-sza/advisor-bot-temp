# Advisor Bot AI - API

Steps to Run:

1. Run `pip -m venv venv`
2. Activate your pip enviroment
3. Create a `.env` file then places your `API_KEY=""` variable in it
4. Run `uvicorn app.main:app --reload`
5. Access `http://127.0.0.1:8000/docs` to see the API documentation